# this script provides utility functions
import os
import pickle

import pandas as pd


class Utils:
    def __init__(self) -> None:

        """
        function to initialize object.
        """
        pass

    def load_project_data(self, data_path, file_name):

        """
        function to load data in pandas dataframe.
        """

        csv_path = os.path.join(data_path, file_name)
        data = pd.read_csv(csv_path)
        return data

    def store_dataframe(self, data, data_path, file_name):
        """
        function to save pandas dataframe in csv.
        """

        csv_path = os.path.join(data_path, file_name)
        data.to_csv(csv_path)

    def load_pickle(self, artifact_path, file_name):
        """
        function to load pickle file from artifact directory.
        """

        pickle_path = os.path.join(artifact_path, file_name)
        artifact = pickle.load(open(pickle_path, "rb"))
        return artifact

    def store_pickle(self, data, artifact_path, file_name):
        """
        function to load pickle file from artifact directory.
        """

        pickle_path = os.path.join(artifact_path, file_name)
        pickle.dump(data, open(pickle_path, "wb"))
