# this file contains script to download data
import argparse
import os
import tarfile
from pathlib import Path
import sys
from six.moves import urllib

FILE_PATH = Path(__file__)
PROJECT_DIR = FILE_PATH.resolve().parents[2]
ARTIFACTS_DIR = os.path.join(PROJECT_DIR, "artifacts")
DATA_DIR = os.path.join(PROJECT_DIR, "datasets")


class Data:

    __slots__ = ("data_url", "data_folder_name")

    def __init__(self, data_url) -> None:

        """
        this function returns object of this class.
        """
        self.data_url = data_url
        self.data_folder_name = os.path.join(DATA_DIR, "raw")
        pass

    def fetch_housing_data(self):

        """
        function to extract housing data from zip file
        and consequently store data in a folder.
        """

        os.makedirs(self.data_folder_name, exist_ok=True)
        tgz_path = os.path.join(
            self.data_folder_name, "data.tgz")
        urllib.request.urlretrieve(self.data_url, tgz_path)
        data_tgz = tarfile.open(tgz_path)
        data_tgz.extractall(path=self.data_folder_name)
        data_tgz.close()


def main():

    parser = argparse.ArgumentParser(
        description="To load data related to project from specified url."
    )
    parser.add_argument(
        "-u",
        "--url",
        help="Provide a valid url from which to extract data.",
        default="https://raw.githubusercontent.com/ageron/handson-ml/"
                "master/datasets/housing/housing.tgz"
    )

    args = parser.parse_args()
    data_loader = Data(args.url)
    data_loader.fetch_housing_data()

if __name__ == "__main__":
    main()
