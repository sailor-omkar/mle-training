# this script performs exploratory data analysis.
import argparse
import os
from pathlib import Path

import pandas as pd
import house_price_prediction.data_scripts.create_features as cf

FILE_PATH = Path(__file__)
PROJECT_DIR = FILE_PATH.resolve().parents[2]
ARTIFACTS_DIR = os.path.join(PROJECT_DIR, "artifacts")
DATA_DIR = os.path.join(PROJECT_DIR, "datasets")


class ExploreData:
    def __init__(self) -> None:
        """
        function to initialize object.
        """
        self.feature_eng_obj = cf.FetureEngineer()
        pass

    def load_project_data(self, data_path, file_name):

        """
        function to load housing data in pandas dataframe.
        """

        csv_path = os.path.join(data_path, file_name)
        self.data = pd.read_csv(csv_path)

    def scatter_plot(self, x, y, **kwargs):
        """
        function returns scatter plot between the features.
        """
        return self.data.plot(kind="scatter", x=x, y=y, **kwargs)

    def correlation_matrix(self, **kwargs):
        """
        function returns correlation between features.
        """
        return self.data.corr()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="To explore data")
    parser.add_argument(
        "-d",
        "--data_path",
        help="Provide valid data path.",
        default=os.path.join(DATA_DIR, "processed"),
    )

    parser.add_argument(
        "-f", "--file_name", help=" Provide a file name.", default="train.csv"
    )

    args = parser.parse_args()

    data_explorer = ExploreData()
    data_explorer.load_project_data(data_path=args.data_path, file_name=args.file_name)

    # see scatter plot between latitude and longitude
    data_explorer.scatter_plot(x="longitude", y="latitude", alpha=0.1)

    # see covariance matrix
    corr_matrix = data_explorer.correlation_matrix()
    corr_matrix["median_house_value"].sort_values(ascending=False)
